# qlearningAgents.py
# ------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from game import *
from learningAgents import ReinforcementAgent
from featureExtractors import *
from backend import ReplayMemory

import backend
import gridworld

import random, util, math
import numpy as np
import copy


class QLearningAgent(ReinforcementAgent):
    """
      Q-Learning Agent
      Functions you should fill in:
        - computeActionAndValueFromQValues
        - getQValue
        - getAction
        - update
      Instance variables you have access to
        - self.epsilon (exploration prob)
        - self.alpha (learning rate)
        - self.discount (discount rate)
      Functions you should use
        - self.getLegalActions(state)
          which returns legal actions for a state
    """

    def __init__(self, **args):
        "You can initialize Q-values here..."
        ReinforcementAgent.__init__(self, **args)
        self.qvalues = util.Counter()

    def getQValue(self, state, action):
        """
          Returns Q(state,action)
          Should return 0.0 if we have never seen a state
          or the Q node value otherwise
        """
        "*** YOUR CODE HERE ***"
        # 如果该状态-动作对不存在于qvalues中，返回0.0
        return self.qvalues[(state, action)]

    def computeActionAndValueFromQValues(self, state):
        """
          Compute the best action to take in a state and its Q-value. Note
          that if there are no legal actions, which is the case at the
          terminal state, you should return None, 0.0.
        """
        "*** YOUR CODE HERE ***"
        legal_actions = self.getLegalActions(state)

        if not legal_actions:
            return None, 0.0

        # 找到所有合法动作的Q值
        action_qvalues = []
        for action in legal_actions:
            q_value = self.getQValue(state, action)
            action_qvalues.append((q_value, action))

        # 找到最大的Q值
        max_qvalue = max(action_qvalues, key=lambda x: x[0])[0]

        # 收集所有具有最大Q值的动作（处理平局情况）
        best_actions = [action for q_value, action in action_qvalues if q_value == max_qvalue]

        # 随机选择一个最佳动作
        best_action = random.choice(best_actions)

        return best_action, max_qvalue

    def getAction(self, state):
        """
          Compute the action to take in the current state.  With
          probability self.epsilon, we should take a random action and
          take the best policy action otherwise.  Note that if there are
          no legal actions, which is the case at the terminal state, you
          should choose None as the action.
          HINT: You might want to use util.flipCoin(prob)
          HINT: To pick randomly from a list, use random.choice(list)
        """
        # Pick Action
        legalActions = self.getLegalActions(state)

        if not legalActions:
            return None

        # 使用epsilon-贪婪策略
        if util.flipCoin(self.epsilon):
            # 探索：随机选择动作
            return random.choice(legalActions)
        else:
            # 利用：选择最佳动作
            best_action, _ = self.computeActionAndValueFromQValues(state)
            return best_action

    def update(self, state, action, nextState, reward: float):
        """
          The parent class calls this to observe a
          state = action => nextState and reward transition.
          You should do your Q-Value update here
          NOTE: You should never call this function,
          it will be called on your behalf
        """
        "*** YOUR CODE HERE ***"
        # 获取当前Q值
        current_q = self.getQValue(state, action)

        # 计算下一状态的最大Q值
        if nextState is None or self.getLegalActions(nextState) == []:
            # 如果是终止状态，未来价值为0
            max_next_q = 0.0
        else:
            _, max_next_q = self.computeActionAndValueFromQValues(nextState)

        # Q-learning更新公式
        # Q(s,a) = Q(s,a) + alpha * [reward + gamma * max_a' Q(s',a') - Q(s,a)]
        new_q = current_q + self.alpha * (reward + self.discount * max_next_q - current_q)

        # 更新Q值
        self.qvalues[(state, action)] = new_q
    def getPolicy(self, state):
        return self.computeActionAndValueFromQValues(state)[0]

    def getValue(self, state):
        return self.computeActionAndValueFromQValues(state)[1]


class PacmanQAgent(QLearningAgent):
    "Exactly the same as QLearningAgent, but with different default parameters"

    def __init__(self, epsilon=0.05, gamma=0.8, alpha=0.2, numTraining=0, **args):
        """
        These default parameters can be changed from the pacman.py command line.
        For example, to change the exploration rate, try:
            python pacman.py -p PacmanQLearningAgent -a epsilon=0.1
        alpha    - learning rate
        epsilon  - exploration rate
        gamma    - discount factor
        numTraining - number of training episodes, i.e. no learning after these many episodes
        """
        args['epsilon'] = epsilon
        args['gamma'] = gamma
        args['alpha'] = alpha
        args['numTraining'] = numTraining
        self.index = 0  # This is always Pacman
        QLearningAgent.__init__(self, **args)

    def getAction(self, state):
        """
        Simply calls the getAction method of QLearningAgent and then
        informs parent of action for Pacman.  Do not change or remove this
        method.
        """
        action = QLearningAgent.getAction(self, state)
        self.doAction(state, action)
        return action


class ApproximateQAgent(PacmanQAgent):
    """
       ApproximateQLearningAgent
       You should only have to overwrite getQValue
       and update.  All other QLearningAgent functions
       should work as is.
    """

    def __init__(self, extractor='IdentityExtractor', **args):
        self.featExtractor = util.lookup(extractor, globals())()
        PacmanQAgent.__init__(self, **args)
        self.weights = util.Counter()

    def getWeights(self):
        return self.weights

    def getQValue(self, state, action):
        """
          Should return Q(state,action) = w * featureVector
          where * is the dotProduct operator
        """
        "*** YOUR CODE HERE ***"
        # 获取特征向量
        features = self.featExtractor.getFeatures(state, action)

        # 计算权重和特征的点积：Q(s,a) = Σ w_i * f_i(s,a)
        q_value = 0.0
        for feature, value in features.items():
            q_value += self.weights[feature] * value

        return q_value

    def update(self, state, action, nextState, reward: float):
        """
           Should update your weights based on transition
        """
        "*** YOUR CODE HERE ***"
        # 获取当前状态-动作对的特性
        features = self.featExtractor.getFeatures(state, action)

        # 计算当前Q值
        current_q = self.getQValue(state, action)

        # 计算下一状态的最大Q值
        if nextState is None:
            max_next_q = 0.0
        else:
            next_actions = self.getLegalActions(nextState)
            if not next_actions:
                max_next_q = 0.0
            else:
                _, max_next_q = self.computeActionAndValueFromQValues(nextState)

        # 计算目标值：r + γ * max_a' Q(s',a')
        target = reward + self.discount * max_next_q

        # 计算差值：目标值 - 当前Q值
        difference = target - current_q

        # 更新权重：w_i ← w_i + α * difference * f_i(s,a)
        for feature, value in features.items():
            self.weights[feature] += self.alpha * difference * value

    def final(self, state):
        """Called at the end of each game."""
        # call the super-class final method
        PacmanQAgent.final(self, state)

        # did we finish training?
        if self.episodesSoFar == self.numTraining:
            # you might want to print your weights here for debugging
            "*** YOUR CODE HERE ***"
            pass
