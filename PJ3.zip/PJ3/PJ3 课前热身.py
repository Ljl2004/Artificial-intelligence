"""
问题0.1：
variableList（变量列表）：字符串列表，存储贝叶斯网络中的所有变量名称。
示例：['Pacman', 'Ghost0', 'Ghost1', 'Obs0', 'Obs1']
数据结构：list[str]

edgeTuplesList（边列表）：元组列表，表示贝叶斯网络中的有向边，每个元组(parent, child)表示从父节点到子节点的边。
示例：[('Ghost0', 'Obs0'), ('Ghost1', 'Obs1'), ('Pacman', 'Obs0'), ('Pacman', 'Obs1')]
数据结构：list[tuple[str, str]]

variableDomainsDict（变量域字典）：字典，将每个变量映射到其可能取值的列表（定义变量的取值范围）。
示例：{'Pacman': [(0,0), (0,1), (1,0), (1,1)], 'Ghost0': [(0,0), (0,1), (1,0), (1,1)], ...}
数据结构：dict[str, list]
"""

"""
问题0.2：
obs_factor = Factor(['Obs0'], ['Ghost0', 'Pacman'], variableDomainsDict)
"""

"""
问题0.3：
ghost_cpt = bayesNet.getCPT('Ghost0')
"""